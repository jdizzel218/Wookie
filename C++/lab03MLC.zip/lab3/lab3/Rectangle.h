#pragma once

class Rectangle {

public:
	Rectangle(int length, int width);

};

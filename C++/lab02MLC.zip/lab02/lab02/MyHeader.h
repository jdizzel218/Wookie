#pragma once //make sure .h file is only included once in a .cpp solution.


using namespace std;

void myFunc() {

	cout << "Hello, You are in my function, which is  in a header file." << endl;
}

﻿//Project Prolog
//Name: Matthew L. Cranford
//CS 1400 Section 001
//Project: CS 1400_Lab_02
//Date: 8/29/2015 1:46 PM
//
// I decalre that the following code was written by me or provided
// by the instructor for this project. I understand that copying source
// code from any other source constitutes cheating, and that I will recieve
// a zero on this project if I am found in violation of this policy.
// ----------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_02
{
    public partial class FrmMain : Form
    {
        /// <summary>
        /// Purpose: FrmMain() default Constructor method
        /// </summary>
        public FrmMain()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }// End Class FrmMain
}//End namespace Lab_02

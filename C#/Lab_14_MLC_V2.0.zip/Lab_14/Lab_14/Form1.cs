﻿// File/Project Prolog
// Name: Matthew Cranford
// CS 1400 Section 001
// Project: Lab_14
// Date: 10/28/2015 2:25 PM
//
// I declare that the following code was written by me or provided 
// by the instructor for this project. I understand that copying source
// code from any other source constitutes cheating, and that I will receive
// a zero on this project if I am found in violation of this policy.
// ---------------------------------------------------------------------------

/*

Pseudo-Code:

1. Create a class for a right Triangle.

*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_14
{
    public partial class FrmMain : Form
    {
        /// <summary>
        /// Purpose: Main Entry point of program.
        /// </summary>
        public FrmMain()
        {
            InitializeComponent();
        }
    }
}
